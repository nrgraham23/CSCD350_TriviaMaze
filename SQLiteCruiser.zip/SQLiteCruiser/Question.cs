﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLiteCruiser {
    class Question {

        enum QType { SHORT=1, TF, MULTI };
        enum QAux { TEXT=1, IMAGE, SOUND };

        String[] questionChoices = new String[4] { "", "", "", "" };
        String questionText = "NULL";
        String questionAuxFile = "NULL";
        int questionAnswer = 1; // 1 - 4
        int questionType = 1; // 1 - 3
        int questionAuxiliary = 1; // 1 - 3

        public Question() { }

        //=====================================================================

        public void SetQuestionFromConsole() {

            String input = "";

            Console.WriteLine("Type (1 SHORT, 2 TF, 3 MULTI)");
            SetQType(Scanner.GetIntegerRng(1, 3));

            Console.WriteLine("Aux (1 TEXT, 2 IMAGE, 3 SOUND)");
            SetAuxiliary(Scanner.GetIntegerRng(1, 3));

            if (GetAuxiliary() != 1) {
                Console.WriteLine("Auxiliary file path");
                SetAuxFile(Console.ReadLine());
            }

            Console.WriteLine("Question");
            SetText(Console.ReadLine());

            if (GetQType() == (int)QType.SHORT) {
                Console.WriteLine("Answer");
                input = Console.ReadLine();
                SetChoices(new String[4] { input, "", "", "" });
            }

            if (GetQType() == (int)QType.TF) {
                SetChoices(new String[4] { "TRUE", "FALSE", "", "" });
                Console.WriteLine("Answer (1 TRUE, 2 FALSE)");
                SetAnswer(Scanner.GetIntegerRng(1, 2));
            }

            if (GetQType() == (int)QType.MULTI) {
                String[] options = new String[4];
                for (int i = 1; i <= 4; i++) {
                    Console.WriteLine("Option " + i);
                    options[i - 1] = Console.ReadLine();
                }
                SetChoices(options);
                Console.WriteLine("Answer (1-4)");
                SetAnswer(Scanner.GetIntegerRng(1, 4));
            }
        }

        //=====================================================================

        public void SetText(String text) {
            questionText = text;
        }

        public void SetAnswer(int answer) {
            questionAnswer = answer;
        }

        public void SetQType(int type) {
            questionType = type;
        }

        public void SetAuxiliary(int aux) {
            questionAuxiliary = aux;
        }

        public void SetAuxFile(String path) {
            questionAuxFile = path;
        }

        public void SetChoices(String[] choices) {
            for (int i = 0; i < 4; i++)
                questionChoices[i] = choices[i];
        }

        //=====================================================================

        public String GetText() {
            return questionText;
        }

        public int GetAnswer() {
            return questionAnswer;
        }

        public int GetQType() {
            return questionType;
        }

        public int GetAuxiliary() {
            return questionAuxiliary;
        }

        public String GetAuxFile() {
            return questionAuxFile;
        }

        public String[] GetChoices() {
            return questionChoices;
        }

        //=====================================================================

        public override String ToString() {
            String result = "";

            if (GetQType() == (int)QType.SHORT) {
                result += GetText() + "\n\tAnswer: " + GetChoices()[0];
            }

            if (GetQType() == (int)QType.TF) {
                result += GetText();
                for (int i = 1; i <= 2; i++)
                    result += "\n\t" + i + ". " + GetChoices()[i - 1];
                result += "\n\tAnswer: " + GetChoices()[GetAnswer() - 1];
            }

            if (GetQType() == (int)QType.MULTI) {
                result += GetText();
                for (int i = 1; i <= 4; i++)
                    result += "\n\t" + i + ". " + GetChoices()[i - 1];
                result += "\n\tAnswer: " + GetChoices()[GetAnswer() - 1];
            }

            return result;
        }

        //=====================================================================
    }
}
