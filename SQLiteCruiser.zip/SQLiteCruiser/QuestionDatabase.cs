﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;

namespace SQLiteCruiser {
    class QuestionDatabase {

        /* [DATABASE SETUP]
         * Questions: QIndex SMALLINT, QType SMALLINT, QAuxiliary SMALLINT, QAuxFile VARCHAR(255), QText VARCHAR(255),
         * QAnswer SMALLINT, QOption1 VARCHAR(64), QOption2 VARCHAR(64), QOption3 VARCHAR(64), QOption4 VARCHAR(64)
         */

        SQLiteConnection dbConnection;
        ArrayList dbIgnore = new ArrayList();
        string dbPath;
        int dbEntries;
        Random rand = new Random();
        Question tempQuestion = new Question();

        //=====================================================================

        public QuestionDatabase(string dbPath) {
            this.dbPath = dbPath;
            OpenDatabase();
            CountEntries();
        }

        //=====================================================================

        public void OpenDatabase() {
            dbConnection = new SQLiteConnection("Data Source=" + dbPath + ";Version=3;");
            dbConnection.Open();
        }

        //=====================================================================

        public void CloseDatabase() {
            dbConnection.Close();
        }

        //=====================================================================

        public void Menu() {
            int choice, index;
            Question pointer = null;
            while (true) {
                Console.WriteLine("======[DATABASE CONSOLE MENU]======\n1. Get Random Question\n2. Print the Database" +
                                  "\n3. Add Question to Database\n4. Remove Question from Database\n5. Clear Ignore List\n6: Quit\nChoose:");
                choice = Scanner.GetIntegerRng(1, 6);
                Console.WriteLine("===================================");
                switch (choice) {
                    case 1:
                        pointer = RandomQuestion();
                        if (pointer != null)
                        Console.WriteLine(pointer.ToString());
                        break;
                    case 2:
                        PrintDatabase();
                        break;
                    case 3:
                        tempQuestion.SetQuestionFromConsole();
                        AddQuestionToDatabase(tempQuestion);
                        break;
                    case 4:
                        Console.WriteLine("Delete Entry\n(1 - " + dbEntries + " or " + (dbEntries+1) + " to cancel)");
                        index = Scanner.GetIntegerRng(1, dbEntries+1);
                        DeleteQuestionFromDatabase(index);
                        break;
                    case 5:
                        Console.WriteLine("Unignored E'rything!");
                        UnignoreAll();
                        break;
                    case 6:
                        CloseDatabase();
                        return;
                }
            }
        }

        //=====================================================================

        public void PrintDatabase() {
            string sql = "SELECT * FROM Questions ORDER BY QIndex";
            SQLiteCommand command = new SQLiteCommand(sql, dbConnection);
            SQLiteDataReader reader = command.ExecuteReader();

            while (reader.Read()) {
                tempQuestion.SetQType(Convert.ToInt32("" + reader["QType"]));
                tempQuestion.SetAuxiliary(Convert.ToInt32("" + reader["QAuxiliary"]));
                tempQuestion.SetAuxFile("" + reader["QType"]);
                tempQuestion.SetText("" + reader["QText"]);
                tempQuestion.SetAnswer(Convert.ToInt32(reader["QAnswer"]));
                tempQuestion.SetChoices(new String[4] { "" + reader["QOption1"], "" + reader["QOption2"], "" + reader["QOption3"], "" + reader["QOption4"] });
                Console.WriteLine(reader["QIndex"] + ": " + tempQuestion.ToString());
            }
        }

        //=====================================================================

        public Question RandomQuestion() {

            if (!HasQuestions())
                return null;

            int index = -1;
            do {
                index = rand.Next(dbEntries) + 1;
            } while (!ValidIndex(index));

            Console.WriteLine("QIndex = " + index);

            string sql = "SELECT * FROM Questions WHERE QIndex = " + index;
            SQLiteCommand command = new SQLiteCommand(sql, dbConnection);
            SQLiteDataReader reader = command.ExecuteReader();
            reader.Read();

            tempQuestion.SetQType(Convert.ToInt32("" + reader["QType"]));
            tempQuestion.SetAuxiliary(Convert.ToInt32("" + reader["QAuxiliary"]));
            tempQuestion.SetAuxFile("" + reader["QType"]);
            tempQuestion.SetText("" + reader["QText"]);
            tempQuestion.SetAnswer(Convert.ToInt32(reader["QAnswer"]));
            tempQuestion.SetChoices(new String[4] { "" + reader["QOption1"], "" + reader["QOption2"], "" + reader["QOption3"], "" + reader["QOption4"] });

            dbIgnore.Add(index);

            return tempQuestion;
        }

        //=====================================================================

        public void AddQuestionToDatabase(Question q) {
            int index = dbEntries + 1;
            String sql = "INSERT INTO Questions (QIndex,QType,QAuxiliary,QAuxFile,QText,QAnswer,QOption1,QOption2,QOption3,QOption4) " +
                         "VALUES (" + index + ", " + q.GetQType() + ", " + q.GetAuxiliary() + ", \"" + q.GetAuxFile() + "\", \"" +
                         tempQuestion.GetText() + "\", " + q.GetAnswer() + ", \"" + q.GetChoices()[0] + "\", \"" + q.GetChoices()[1] + "\", \"" +
                         q.GetChoices()[2] + "\", \"" + q.GetChoices()[3] + "\")";
            SQLiteCommand command = new SQLiteCommand(sql, dbConnection);
            command.ExecuteNonQuery();
            dbEntries++;
        }

        //=====================================================================

        public void DeleteQuestionFromDatabase(int index) {
            if (index < 1 || index > dbEntries)
                return;
            String sql = "DELETE FROM Questions WHERE QIndex = " + index;
            SQLiteCommand command = new SQLiteCommand(sql, dbConnection);
            command.ExecuteNonQuery();
            if (index != dbEntries) {
                sql = "UPDATE Questions SET QIndex = " + index + " WHERE QIndex = " + dbEntries;
                command = new SQLiteCommand(sql, dbConnection);
                command.ExecuteNonQuery();
            }
            dbEntries--;
        }

        //=====================================================================

        private bool HasQuestions() {
            if (dbIgnore.Count == dbEntries) {
                Console.WriteLine("No more questions!");
                return false;
            }
            return true;
        }

        //=====================================================================

        private bool ValidIndex(int index) {
            if (dbIgnore.IndexOf(index) == -1)
                return true;
            return false;
        }

        //=====================================================================

        private void CountEntries() {
            int entryCount = 0;
            string sql = "SELECT * FROM Questions";
            SQLiteCommand command = new SQLiteCommand(sql, dbConnection);
            SQLiteDataReader reader = command.ExecuteReader();
            while (reader.Read())
                entryCount++;
            dbEntries = entryCount;
        }

        //=====================================================================

        private void UnignoreAll() {
            dbIgnore.Clear();
        }

        //=====================================================================
    }
}
