﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLiteCruiser {
    class SQLTest {

        public static void Main() {
            QuestionDatabase db = new QuestionDatabase("../../gameqs.db");
            db.Menu();
        }
    }
}
