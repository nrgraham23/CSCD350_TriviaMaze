﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SQLiteCruiser {
    class Scanner {

       public static int GetIntegerRng(int min, int max) {
            String sInput;
            int nInput = -1;
            bool valid = false;

            while (!valid) {
                sInput = Console.ReadLine();
                try {
                    nInput = Convert.ToInt32(sInput);
                    if (nInput >= min && nInput <= max)
                        valid = true;
                    else
                        throw new Exception();
                }
                catch (Exception) {
                    Console.WriteLine("Invalid input.");
                    continue;
                }
            }
            return nInput;
        }
    }
}
