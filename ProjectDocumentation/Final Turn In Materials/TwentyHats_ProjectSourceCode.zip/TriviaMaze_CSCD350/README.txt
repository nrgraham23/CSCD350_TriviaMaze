To compile and run this program you should open the TriviaMaze_CSCD350 folder and open the project in visual studio.  Hit the run button, and visual studio will compile and run the program.

Alternatively, you can use the installer located in TriviaMaze_CSCD350\Setup2\

To run with Visual Studio, you may need to install the InstallShield Limited Edition plugin found at: http://learn.flexerasoftware.com/content/IS-EVAL-InstallShield-Limited-Edition-Visual-Studio